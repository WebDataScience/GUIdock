import os
from kombu import Exchange, Queue
from datetime import timedelta
BROKER_URL="amqp://%s//" % os.environ.get('mqp_host', 'mqp')

CELERY_ROUTES = {
    'push_data'  : {'queue': 'for_push_data'},
}
CELERYD_PREFETCH_MULTIPLIER = 20

CELERY_TASK_SERIALIZER='pickle'
CELERY_ACCEPT_CONTENT=['pickle']

CELERY_ACKS_LATE=True
