from django.conf.urls import patterns, include, url

from django.contrib import admin
admin.autodiscover()

import authentication as auth

urlpatterns = patterns('',
    url(r'^check/$', auth.is_authenticated, name='is_authenticated'),
    url(r'^google/$', auth.authenticate_with_google, name='google'),
    url(r'^google_authenticate/$', auth.google_authenticate_redirect, name='google_authenticate_redirect'),
)
