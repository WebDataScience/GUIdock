from django.db import models

# Create your models here.
from zlib import compress,decompress
from pickle import dumps,loads

from mongoengine import *
connect('biodepot', host='mongo', connect=False)

from datetime import datetime
class Files(Document):
    file_id = StringField()
    file      = FileField()
    file_name = StringField()
    date_created = DateTimeField(default=datetime.now())

