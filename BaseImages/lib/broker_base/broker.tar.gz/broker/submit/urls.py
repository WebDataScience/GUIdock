from django.conf.urls import patterns, include, url

from views import push,status,upload

urlpatterns = patterns('',
    url(r'^$', status),
    url(r'push/$', push),
    url(r'upload/$', upload),
)

