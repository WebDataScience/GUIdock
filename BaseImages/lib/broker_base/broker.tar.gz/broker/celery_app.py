from __future__ import absolute_import

import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'broker.settings')

from celery import Celery
from celery.task import task
from celery.contrib.batches import Batches
from celery.exceptions import SoftTimeLimitExceeded

from django.conf import settings

app = Celery(broker="mqp")
app.config_from_object('celeryconfig')

retry_policy={
    'max_retries': 0,
    'interval_step':  0.2,
}

def queue_push_req(container_name, file_name, file_content):
    #push_data.apply_async((container_name, file_name, file_content), retry=True, retry_policy=retry_policy)
    push_data.delay(container_name, file_name, file_content)

@app.task(name='push_data', bind=True)
def push_data(self, container_name, file_name, file_id):
    import requests
    from datetime import datetime

    try:
        content = requests.post("http://%s:8000/push/" % (container_name),
                      data={'container': container_name, 'file_id': file_id, 'file_name': file_name},
                      headers = {'Host': '0.0.0.0'}, timeout=2)
    except requests.exceptions.ConnectionError as e:
        raise self.retry(countdown=10)
    except Exception as e:
        print("error2", e)
