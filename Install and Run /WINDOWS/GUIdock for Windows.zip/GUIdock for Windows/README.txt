To run double click on RunGUIdock.sh
Both the docker toolbox and MobaXterm must be installed and the machine restarted before the script is run the first time
