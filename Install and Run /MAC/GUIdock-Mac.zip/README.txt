# INSTALL
# Run install-mac.sh to install required softwares (socat, and XQuartz). 
# Docker Toolbox needs to be downloaded and installed manually from: 
# https://www.docker.com/toolbox
# Usage:

sh install-mac.sh

# RUNNING GUIdock
# start-mac.sh load socat, XQuartz, and Docker engine. 
# In some cases it may be necessary to edit the script and check the IP Address to match
# with your IP Configuration.
# Usage:

sh start-mac.sh

